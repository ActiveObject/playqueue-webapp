/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-plus' : '&#xe004;',
			'icon-minus' : '&#xe047;',
			'icon-mute' : '&#xe043;',
			'icon-first' : '&#xe009;',
			'icon-last' : '&#xe00a;',
			'icon-shuffle' : '&#xe01d;',
			'icon-loop' : '&#xe01c;',
			'icon-repeat' : '&#xe01b;',
			'icon-add' : '&#xe005;',
			'icon-add-2' : '&#xe008;',
			'icon-arrow-left' : '&#xe00b;',
			'icon-appbarbase' : '&#xe00c;',
			'icon-appbarcontrolplay' : '&#xe00d;',
			'icon-appbarcontrolfastforward' : '&#xe00e;',
			'icon-appbarcontrolpause' : '&#xe00f;',
			'icon-appbarcontrolresume' : '&#xe010;',
			'icon-appbarcontrolrewind' : '&#xe011;',
			'icon-appbarcontrolstop' : '&#xe012;',
			'icon-appbararrowleft' : '&#xe013;',
			'icon-appbarlist' : '&#xe014;',
			'icon-appbarbasehover' : '&#xe015;',
			'icon-appbarmagnify' : '&#xe016;',
			'icon-appbarchevrondown' : '&#xe000;',
			'icon-arrow-left-2' : '&#xe007;',
			'icon-arrow-right' : '&#xe001;',
			'icon-arrow-top' : '&#xe006;',
			'icon-heart' : '&#xe002;',
			'icon-cross' : '&#xe003;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};